n=int(input("enter a number"))
if(1<=n<=26):
    print((n-1)*'-'+chr(n+96)+(n-1)*'-')
else:
    print("invalid input")