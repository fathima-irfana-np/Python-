def irgusna():
    start = ord('d') - ord('c')  #1
    end = ord('d') +start #101
    for i in range(start, end):
        print(i)

irgusna()
