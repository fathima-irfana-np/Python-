# import polymorphism
# p1=polymorphism.Car("MARUTI","SUZUKI")
# p1.move()
# print(p1.brand)
# print(p1.model)

import no_numerical_literals_in_1_to_100
obj1=no_numerical_literals_in_1_to_100.irgusna()

# obj= import cheythath.function or importcheythath.dict 