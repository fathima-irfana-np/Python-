print(dir(str))
help(str.rpartition)
help(str.capitalize)