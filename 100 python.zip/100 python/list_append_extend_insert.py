listt=[1,2]
print(listt)

listt.append(3)
print(listt)
listt.extend((5,6))
print(listt)
listt.remove(1)
print(listt)
listt.insert(3,77)
print(listt)
listt.reverse()
print(listt)

listt.pop()
print(listt)