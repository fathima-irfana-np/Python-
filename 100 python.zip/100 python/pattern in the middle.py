n=int(input("enter a number"))
character=chr(96+n)
spaces='-'*(n-1)
print(spaces+character+spaces)
