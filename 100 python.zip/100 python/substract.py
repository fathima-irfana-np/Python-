num1 = int(input("Enter the number A: "))
num2 = int(input("Enter the number B: "))

# Use addition with the negation of num2
result = num1 + (-num2)

print(f"Subtracting {num1} - {num2} = {result}")