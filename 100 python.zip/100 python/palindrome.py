string=input("enter a string")
reverse=string[::-1]
if(string==reverse):
    print("palindrome")
else:
    print("not palindrome")