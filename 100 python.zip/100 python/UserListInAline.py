size=int(input("size?"))
l=[int(input("")) for x in range(size)] 
print(l)
print([x+10 for x in l])