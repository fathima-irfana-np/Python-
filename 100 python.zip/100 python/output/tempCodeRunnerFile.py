
# for i in range(1,size*2+1):
#     dictionary[i]=0
