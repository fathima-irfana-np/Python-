name="irfana"
age="21"
course="MCA"
specify="My name is {}, and my age is {}, course {}"
print(specify.format(name,age,course))