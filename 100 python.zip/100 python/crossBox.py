
for j in range(0,10):
    for i in range(0,10):
        if(i==0 or i==9 or j==0 or j==9 or i==j or i+j==9):
            print("*", end='')
            print("\t", end='')
        else:
            print("\t", end='')
            
    print("\n")

# credits goes to power team cofounder mubashira EA
# credits goes to MANEESHA MANOJ 

      

        