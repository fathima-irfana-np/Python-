dictionary={
    "car":"ferrari",
    "rider":"Louise hamilton"
}
print(dictionary)
dictionary.setdefault("year","2020")
dictionary['new rider']="not found yet"
#use update also
print(dictionary)
print("irfanaNP".translate(str.maketrans('NP','PP')))